var mydb = connect('localhost:27017/#GJOY9NMPca0HrLJ&@a');
