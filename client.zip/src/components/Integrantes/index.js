export { default as Integrantes } from './Integrantes';
