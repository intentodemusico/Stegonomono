import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import './home.css';
import axios from 'axios';

class Home extends Component {
  state = {
    selectedFile: null,
  };
  fileSelectedHandler = event => {
    this.setState({
      selectedFile: event.target.files[0],
    });
  };

  fileUploadHandler = () => {
    axios.post('');
  };
  render() {
    return (
      <div>
        <div className="header">
          <h1>STEGONOMONO</h1>
        </div>

        <div className="texto">
          <p>
            Bienvenido a STEGONOMONO. Esta herramienta permite detectar
            imágenes, que hallan sido alteradas usando esteganografía. Adjunte
            la imagen que desea escanear y presione el botón de Enviar para
            empezar el análisis.
          </p>
        </div>

        <div className="boton">
          <form action="/reportes">
            <input type="file" onChange={this.fileSelectedHandler} />
            <br />
            <br />
            <button OnClick={this.fileUploadHandler}>Upload</button>
            <input type="submit" />
          </form>
        </div>
      </div>
    );
  }
}
export default Home;
